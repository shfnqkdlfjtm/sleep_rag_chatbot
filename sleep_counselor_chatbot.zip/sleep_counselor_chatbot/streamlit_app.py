import streamlit as st
import os

# 1. Streamlit secrets → 환경변수로 등록
for key, value in st.secrets.items():
    os.environ[key] = value

# 2. 필수 환경변수 체크
REQUIRED_VARS = [
    "OPENAI_API_KEY",
    "PINECONE_API_KEY",
    "PINECONE_ENVIRONMENT",
    "PINECONE_INDEX_NAME"
]
missing_vars = [var for var in REQUIRED_VARS if not os.getenv(var)]

if missing_vars:
    st.error(f"Missing required environment variables: {', '.join(missing_vars)}")
    st.info("Please set these variables in Streamlit's secrets management.")
    st.stop()

# 3. 메인 앱 실행
from src.app.main import main

if __name__ == "__main__":
    main()
