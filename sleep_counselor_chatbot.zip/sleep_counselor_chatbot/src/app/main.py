import streamlit as st
from src.utils.initialization import initialize_session_state, clear_session_state, ensure_state_initialization
from src.utils.error_handling import handle_streamlit_errors
from src.components.message_display import apply_chat_styles, display_message
from src.components.chat_components import render_emotion_indicator, render_conversation_stats
from src.app.constants import (
    DEFAULT_PERSONA, 
    DEFAULT_EMOTION, 
    EMOTIONS,
    PERSONA_NAME_MAPPING,
    CBTI_WEEK_LABELS
)
from src.core.services.personas import PERSONAS
from src.core.services.chatbot_service import ChatbotService
from src.app.config import OpenAIConfig
from src.utils.audio_handler import process_recorded_audio
from src.utils.tts_handler import synthesize_speech  # 신규: 음성출력

from datetime import datetime
import time

def get_emotion_from_gpt(prompt: str) -> str:
    """GPT를 통해 텍스트의 감정을 분석합니다."""
    try:
        emotions = ["Anger", "Disgust", "Fear", "Happy", "Neutral", "Sad"]
        emotion_prompt = (
            f"The user said: \"{prompt}\".\n"
            f"Classify the user's input into one of these emotions: {', '.join(emotions)}.\n"
            f"Respond ONLY with the emotion name (e.g., Happy, Neutral)."
        )
        response = st.session_state.chatbot_service.llm.invoke(emotion_prompt)
        detected_emotion = response.content.strip()
        return detected_emotion if detected_emotion in emotions else DEFAULT_EMOTION
    except Exception as e:
        return DEFAULT_EMOTION

def handle_chat_message(prompt: str, current_persona: str, cbti_week: int = None) -> tuple:
    """채팅 메시지를 처리하고 응답/음성 생성."""
    user_emotion = get_emotion_from_gpt(prompt)
    st.session_state.current_emotion = user_emotion

    # CBT-I 코치 & 8주차 분기
    if current_persona == "CBT-I 8주 프로그램 코치" and cbti_week is not None:
        response = st.session_state.chatbot_service.get_cbti_week_response(prompt, cbti_week)
    else:
        response = st.session_state.chatbot_service.get_response(prompt, current_persona)
    
    # TTS 음성 생성
    tts_audio = synthesize_speech(response, lang="ko")
    return user_emotion, response, tts_audio

def add_chat_message(role: str, content: str, emotion: str = None, audio_bytes: bytes = None):
    """대화 기록에 메시지 추가 (음성 포함 가능)"""
    current_time = datetime.now().strftime('%p %I:%M')
    message = {
        "role": role,
        "content": content,
        "timestamp": current_time
    }
    if emotion:
        message["emotion"] = emotion
    if audio_bytes:
        message["audio_bytes"] = audio_bytes
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    st.session_state.messages.append(message)

def update_conversation_stats(emotion: str):
    """대화 통계 업데이트."""
    if 'conversation_stats' not in st.session_state:
        st.session_state.conversation_stats = {'total': 0, 'positive': 0, 'negative': 0}
    st.session_state.conversation_stats['total'] += 1
    if emotion in ['Happy']:
        st.session_state.conversation_stats['positive'] += 1
    elif emotion in ['Anger', 'Disgust', 'Fear', 'Sad']:
        st.session_state.conversation_stats['negative'] += 1

def render_chat_area():
    """채팅 UI 영역 렌더링"""
    st.title("수면상담 챗봇 (음성+CBT-I+RAG)")
    apply_chat_styles()
    messages_container = st.container()
    with messages_container:
        for message in st.session_state.messages:
            display_message(message, persona=st.session_state.selected_persona)
            # 음성출력
            if message.get("audio_bytes"):
                st.audio(message["audio_bytes"], format="audio/mp3")

    # CBT-I 코치면 8주차 선택 노출
    cbti_week = None
    if st.session_state.selected_persona == "CBT-I 8주 프로그램 코치":
        cbti_week = st.selectbox(
            "현재 진행 중인 CBT-I 8주차를 선택하세요:",
            options=list(CBTI_WEEK_LABELS.keys()),
            format_func=lambda x: f"{x}주차 - {CBTI_WEEK_LABELS[x]}"
        )
    
    # 입력/음성 처리
    col1, col2 = st.columns([8,2])
    with col1:
        chat_input = st.text_input("메시지를 입력하세요...", key="chat_input", label_visibility="collapsed")
    with col2:
        audio_bytes = st.file_uploader("음성 파일 (WAV/MP3)", type=["wav", "mp3"])
        if audio_bytes is not None:
            with st.spinner("음성을 분석 중..."):
                text, emotion = process_recorded_audio(audio_bytes)
                if text:
                    user_emotion, response, tts_audio = handle_chat_message(
                        text, st.session_state.selected_persona, cbti_week
                    )
                    update_conversation_stats(user_emotion)
                    add_chat_message("user", f"[음성] {text}", user_emotion)
                    add_chat_message("assistant", response, audio_bytes=tts_audio)
                    st.session_state.current_emotion = user_emotion
                    st.session_state.last_message = text
                    st.success("음성 메시지 처리 완료!")
                else:
                    st.error("음성을 텍스트로 변환하지 못했습니다.")
    send_clicked = st.button("전송", use_container_width=True)
    if (send_clicked or chat_input) and chat_input.strip() and chat_input != st.session_state.get('last_message'):
        user_emotion, response, tts_audio = handle_chat_message(
            chat_input, st.session_state.selected_persona, cbti_week
        )
        update_conversation_stats(user_emotion)
        add_chat_message("user", chat_input, user_emotion)
        add_chat_message("assistant", response, audio_bytes=tts_audio)
        st.session_state.current_emotion = user_emotion
        st.session_state.last_message = chat_input
        st.experimental_rerun()

def render_chat_page():
    """채팅 페이지"""
    persona_url = st.query_params.get("persona")
    if not persona_url:
        st.query_params["page"] = "home"
        st.rerun()
        return
    selected_persona = PERSONA_NAME_MAPPING.get(persona_url, DEFAULT_PERSONA)
    if (not st.session_state.get('initialized') or 
        st.session_state.get('selected_persona') != selected_persona):
        old_messages = st.session_state.get('messages', [])
        clear_session_state()
        initialize_session_state(selected_persona)
        if old_messages and st.session_state.get('selected_persona') == selected_persona:
            st.session_state.messages = old_messages
    st.query_params["page"] = "chat"
    st.query_params["persona"] = persona_url
    render_sidebar()
    render_chat_area()

def render_sidebar():
    with st.sidebar:
        st.title("수면상담 RAG 챗봇 💤")
        if st.button("← 다른 페르소나 선택", key="change_persona_button"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            for param in list(st.query_params.keys()):
                del st.query_params[param]
            st.query_params["page"] = "home"
            st.rerun()
            return
        st.markdown("### 사용 방법\n"
            "1. 채팅 입력 또는 음성 파일 업로드\n"
            "2. (CBT-I 코치 선택 시) 8주차 단계 지정\n"
            "3. 감정 분석/수면 상담/실전 가이드 안내\n"
        )
        st.markdown(f"### 현재 페르소나: {st.session_state.get('selected_persona','')}")
        ensure_state_initialization('current_emotion', DEFAULT_EMOTION)
        ensure_state_initialization('conversation_stats', {'total': 0, 'positive': 0, 'negative': 0})
        render_emotion_indicator(st.session_state.current_emotion)
        render_conversation_stats(st.session_state.conversation_stats)

def main():
    st.set_page_config(
        page_title="수면상담 챗봇 (음성+CBT-I+RAG)",
        page_icon="💤",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    current_page = st.query_params.get("page", "home")
    if current_page == "chat":
        render_chat_page()
    else:
        from src.app.home import render_home
        render_home()

if __name__ == "__main__":
    main()
