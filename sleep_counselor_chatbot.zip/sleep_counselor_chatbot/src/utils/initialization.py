import streamlit as st
from datetime import datetime
from src.app.config import OpenAIConfig
from src.app.constants import DEFAULT_PERSONA

def initialize_chatbot_service():
    """ChatbotService 초기화"""
    from src.core.services.chatbot_service import ChatbotService
    return ChatbotService(OpenAIConfig())

def initialize_session_state():
    """Initialize session state variables for 수면상담 RAG 챗봇 with CBT-I/페르소나/TTS."""
    if 'initialized' not in st.session_state:
        st.session_state.initialized = False
    
    if not st.session_state.initialized:
        # Chat state
        st.session_state.messages = []
        st.session_state.last_message = None
        st.session_state.current_emotion = "Neutral"
        
        # === [추가] ===
        st.session_state.selected_persona = "전문가 상담가"   # 기본 페르소나 (또는 "CBT-I 8주 프로그램 코치" 등)
        st.session_state.cbti_week = 1                        # CBT-I 8주차 상태 (기본 1주차)
        st.session_state.tts_enabled = False                  # TTS On/Off (기본 OFF, UI 연동 필요)
        # ==============
        
        # 녹음 관련 상태
        st.session_state.is_recording = False
        st.session_state.audio_recorder = None
        
        # Conversation stats (감정 통계 등은 유지)
        st.session_state.conversation_stats = {
            'total': 0,
            'positive': 0,
            'negative': 0
        }
        
        # Initialize chatbot service
        st.session_state.chatbot_service = initialize_chatbot_service()
        
        st.session_state.initialized = True
