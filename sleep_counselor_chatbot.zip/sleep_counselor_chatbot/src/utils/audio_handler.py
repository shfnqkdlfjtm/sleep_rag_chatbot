import torchaudio
import torch
import os
from transformers import pipeline, AutoModelForAudioClassification, AutoProcessor
from pydub import AudioSegment
import speech_recognition as sr
import whisper
import pyaudio
import wave
import threading
import time
import streamlit as st

# 음성 감정 인식 모델 설정
MODEL_NAME = "forwarder1121/ast-finetuned-model"
processor = AutoProcessor.from_pretrained(MODEL_NAME)
model = AutoModelForAudioClassification.from_pretrained(MODEL_NAME)

class AudioRecorder:
    def __init__(self):
        self.frames = []
        self.stream = None
        self.p = None
        self._recording = False
        
    @property
    def is_recording(self):
        return self._recording
        
    @is_recording.setter
    def is_recording(self, value):
        self._recording = value
        
    def start_recording(self):
        # ... (기존 코드 동일)
        # 이하 생략

    def stop_recording(self):
        # ... (기존 코드 동일)
        # 이하 생략

def predict_audio_emotion(audio_path: str) -> str:
    # ... (기존 코드 동일)
    # 이하 생략

def transcribe_audio(audio_path: str) -> str:
    # ... (기존 코드 동일)
    # 이하 생략

def process_recorded_audio(return_audio_file=False):
    """
    실시간 녹음된 오디오를 처리합니다.

    return_audio_file: True일 경우 텍스트, 감정, 오디오 파일 경로를 반환(TTS 등 활용 위해)
    """
    try:
        if not hasattr(st.session_state, 'audio_recorder') or not st.session_state.audio_recorder:
            print("[ERROR] AudioRecorder가 초기화되지 않았습니다.")
            return (None, "Neutral", None) if return_audio_file else (None, "Neutral")
            
        # 녹음 중지 및 파일 저장
        recorder = st.session_state.audio_recorder
        st.session_state.audio_recorder = None
        
        audio_path = recorder.stop_recording()
        
        if not audio_path or not os.path.exists(audio_path):
            print("[ERROR] 오디오 파일이 생성되지 않았습니다.")
            return (None, "Neutral", None) if return_audio_file else (None, "Neutral")
        
        try:
            text = transcribe_audio(audio_path)
            if text:
                emotion = predict_audio_emotion(audio_path)
            else:
                emotion = "Neutral"

            # ----
            # 만약 TTS/음성 답변 저장 등에서 이 파일을 쓰고 싶으면
            # return_audio_file=True로 호출해서 경로도 반환
            # ----
            if return_audio_file:
                # 주의: 후처리에서 직접 삭제 필요
                return text, emotion, audio_path
            else:
                try:
                    os.remove(audio_path)
                except Exception as e:
                    print(f"[WARNING] 임시 파일 삭제 실패: {str(e)}")
                return text, emotion
            
        except Exception as e:
            print(f"[ERROR] 음성 처리 중 오류 발생: {str(e)}")
            if os.path.exists(audio_path):
                try:
                    os.remove(audio_path)
                except:
                    pass
            return (None, "Neutral", None) if return_audio_file else (None, "Neutral")
            
    except Exception as e:
        print(f"[ERROR] 전체 처리 중 오류 발생: {str(e)}")
        return (None, "Neutral", None) if return_audio_file else (None, "Neutral")

# === 추가 TIP ===
# 만약 답변 생성 시 바로 TTS로 음성 변환하고자 하면(예: message_handler.py 등에서)
# process_recorded_audio(return_audio_file=True)로 호출해서 음성 경로를 TTS로 넘겨주면 됩니다.
